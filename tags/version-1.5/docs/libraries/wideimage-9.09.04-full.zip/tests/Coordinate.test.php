<?php
	/**
    This file is part of WideImage.
		
    WideImage is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.
		
    WideImage is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.
		
    You should have received a copy of the GNU Lesser General Public License
    along with WideImage; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
  **/
	
	/**
	 * @package Tests
	 */
	class CoordinateTest extends UnitTestCase
	{
		function testParse()
		{
			$this->assertIdentical(array('type' => 'abs', 'value' => '+23.6'), WideImage_Coordinate::parse(23.6));
			$this->assertIdentical(array('type' => 'abs', 'value' => '-23.6'), WideImage_Coordinate::parse(-23.6));
			$this->assertIdentical(array('type' => 'abs', 'value' => '+12.345'), WideImage_Coordinate::parse('12.345'));
			$this->assertIdentical(array('type' => 'abs', 'value' => '-12.345'), WideImage_Coordinate::parse('-12.345'));
			$this->assertIdentical(array('type' => 'abs', 'value' => '+23'), WideImage_Coordinate::parse(23));
			$this->assertIdentical(array('type' => 'abs', 'value' => '-23'), WideImage_Coordinate::parse(-23));
			$this->assertIdentical(array('type' => 'abs', 'value' => '+16'), WideImage_Coordinate::parse('16'));
			$this->assertIdentical(array('type' => 'abs', 'value' => '-16'), WideImage_Coordinate::parse('-16'));
			$this->assertIdentical(array('type' => 'abs', 'value' => '-76%'), WideImage_Coordinate::parse('-76%'));
			$this->assertIdentical(array('type' => 'abs', 'value' => '+6%'), WideImage_Coordinate::parse('6%'));
			
			$this->assertIdentical(array('type' => 'cal', 'pivot' => '+20.34', 'value' => '+12'), WideImage_Coordinate::parse('20.34 + 12'));
			$this->assertIdentical(array('type' => 'cal', 'pivot' => '-15.1', 'value' => '+7'), WideImage_Coordinate::parse('-15.1 + 7'));
			$this->assertIdentical(array('type' => 'cal', 'pivot' => '-13.7%', 'value' => '+12.5%'), WideImage_Coordinate::parse('-  13.7% + 12.5%'));
			$this->assertIdentical(array('type' => 'cal', 'pivot' => '+100%', 'value' => '-0'), WideImage_Coordinate::parse('100% - 0'));
			
			$this->assertIdentical(array('type' => 'cal', 'pivot' => '+100%', 'value' => '-0'), WideImage_Coordinate::parse('100% - 0'));
		}
		
		function testEvaluate()
		{
			$this->assertIdentical(400, WideImage_Coordinate::evaluate('+200%', 200));
			$this->assertIdentical(-1, WideImage_Coordinate::evaluate('-1', 200));
			$this->assertIdentical(10, WideImage_Coordinate::evaluate('+10', 200));
			$this->assertIdentical(40, WideImage_Coordinate::evaluate('+20%', 200));
			$this->assertIdentical(-11, WideImage_Coordinate::evaluate('-11.23', 200));
			$this->assertIdentical(-30, WideImage_Coordinate::evaluate('-15%', 200));
		}
		
		function testFix()
		{
			$this->assertIdentical(10, WideImage_Coordinate::fix(100, '10%'));
			$this->assertIdentical(10, WideImage_Coordinate::fix(100, '10'));
			
			$this->assertIdentical(-10, WideImage_Coordinate::fix(100, '-10%'));
			$this->assertIdentical(-1, WideImage_Coordinate::fix(100, '-1'));
			$this->assertIdentical(-50, WideImage_Coordinate::fix(100, '-50%'));
			$this->assertIdentical(-100, WideImage_Coordinate::fix(100, '-100%'));
			$this->assertIdentical(-1, WideImage_Coordinate::fix(20, '-5%'));
			
			$this->assertIdentical(300, WideImage_Coordinate::fix(200, '150.12%'));
			$this->assertIdentical(150, WideImage_Coordinate::fix(200, '150'));
			
			$this->assertIdentical(100, WideImage_Coordinate::fix(200, '100%-50%'));
			$this->assertIdentical(200, WideImage_Coordinate::fix(200, '100%'));
			
			$this->assertIdentical(130, WideImage_Coordinate::fix(300, '50%     -20'));
			$this->assertIdentical(12, WideImage_Coordinate::fix(300, ' 12 - 0'));
			
			$this->assertIdentical(15, WideImage_Coordinate::fix(30, '50%'));
			$this->assertIdentical(15, WideImage_Coordinate::fix(30, '50%-0'));
			$this->assertIdentical(15, WideImage_Coordinate::fix(30, '50%+0'));
			$this->assertIdentical(0, WideImage_Coordinate::fix(30, ' -  50%  +   50%'));
			$this->assertIdentical(30, WideImage_Coordinate::fix(30, ' 50%  + 49.6666%'));
		}
	}
?>